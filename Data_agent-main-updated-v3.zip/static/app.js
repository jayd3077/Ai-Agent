const ARC = 2 * Math.PI * 18; // stroke-dasharray for r=18
let decisionInterval = 5;

const REGION_META = {
  "us-east":  { flag: "🇺🇸", label: "USA — Virginia" },
  "eu-north": { flag: "🇮🇸", label: "Iceland" },
  "eu-west":  { flag: "🇩🇰", label: "Denmark" },
  "ap-south": { flag: "🇮🇳", label: "India — Mumbai" },
  "sa-east":  { flag: "🇧🇷", label: "Brazil — São Paulo" },
};

function chipClass(chip) {
  if (chip.temperature_c >= 68)  return "hot";
  if (chip.utilization >= 0.60)  return "busy";
  if (chip.active_tasks > 0)     return "ok";
  return "idle";
}

function renderChip(cid, chip) {
  const cls   = chipClass(chip);
  const util  = Math.round(chip.utilization * 100);
  const temp  = chip.temperature_c.toFixed(0);
  const label = util > 0 ? `${util}%` : "—";
  return `
    <div class="chip-cell ${cls}" title="${cid}&#10;Util: ${util}%&#10;Temp: ${temp}°C&#10;Tasks: ${chip.active_tasks}">
      <span class="chip-util">${label}</span>
      <span class="chip-temp">${temp}°C</span>
      <div class="chip-bar-wrap"><div class="chip-bar" style="width:${util}%"></div></div>
    </div>`;
}

function renderServer(sid, server) {
  const chips = Object.entries(server.chipsets)
    .map(([cid, c]) => renderChip(cid, c)).join("");
  const avgUtil = Math.round(
    Object.values(server.chipsets).reduce((s, c) => s + c.utilization, 0)
    / Object.values(server.chipsets).length * 100
  );
  const short = sid.split("-").slice(-2).join("-");
  return `
    <div class="server-card">
      <div class="server-header">
        <span class="server-name">${short}</span>
        <span class="server-tier-tag ${server.tier}">${server.tier}</span>
      </div>
      <div class="chips-grid">${chips}</div>
      <div class="server-util-bar">
        <div class="server-util-fill" style="width:${avgUtil}%"></div>
      </div>
    </div>`;
}

function renderRegion(rid, region) {
  const meta   = REGION_META[rid] || { flag: "🌐", label: rid };
  const cls    = region.energy_source === "green" ? "green-card" : "fossil-card";
  const etag   = region.energy_source === "green" ? "green" : "fossil";
  const servers = Object.entries(region.servers)
    .map(([sid, s]) => renderServer(sid, s)).join("");
  return `
    <div class="region-card ${cls}">
      <div class="region-header">
        <div class="region-title">
          <span class="region-flag">${meta.flag}</span>
          <div>
            <div class="region-name">${meta.label}</div>
            <div class="region-id">${rid}</div>
          </div>
          <span class="energy-tag ${etag}">${region.energy_source}</span>
        </div>
        <div class="region-kpis">
          <div class="kpi">
            <div class="kpi-val">$${region.electricity_price}</div>
            <div class="kpi-lbl">per kWh</div>
          </div>
          <div class="kpi">
            <div class="kpi-val">${region.carbon_g_per_kwh}</div>
            <div class="kpi-lbl">gCO₂/kWh</div>
          </div>
        </div>
      </div>
      <div class="region-body">
        <div class="servers-grid">${servers}</div>
      </div>
    </div>`;
}

function computeGlobalStats(snapshot) {
  let totalTasks = 0, totalTemp = 0, tempCount = 0;
  let cheapest = { price: Infinity, name: "—" };
  let greenest = { carbon: Infinity, name: "—" };
  const regions = snapshot.regions || {};
  for (const [rid, region] of Object.entries(regions)) {
    const meta = REGION_META[rid] || { label: rid };
    if (region.electricity_price < cheapest.price)
      cheapest = { price: region.electricity_price, name: meta.label.split("—")[0].trim() };
    if (region.carbon_g_per_kwh < greenest.carbon)
      greenest = { carbon: region.carbon_g_per_kwh, name: meta.label.split("—")[0].trim() };
    for (const server of Object.values(region.servers || {}))
      for (const chip of Object.values(server.chipsets || {})) {
        totalTasks += chip.active_tasks;
        totalTemp  += chip.temperature_c;
        tempCount++;
      }
  }
  return {
    tasks:  totalTasks,
    avgTemp: tempCount ? (totalTemp / tempCount).toFixed(1) : "—",
    cheapest: cheapest.name,
    greenest: greenest.name,
  };
}

async function pollState() {
  try {
    const res  = await fetch("/api/state", { cache: "no-store" });
    const data = await res.json();
    decisionInterval = data.decision_interval_seconds || 5;

    // regions
    const regions = data.snapshot.regions || {};
    document.getElementById("regionsList").innerHTML =
      Object.entries(regions).map(([rid, r]) => renderRegion(rid, r)).join("");

    // timer ring
    const nextIn   = Math.max(0, data.next_decision_in || 0);
    const fraction = nextIn / decisionInterval;
    const offset   = ARC * (1 - fraction);
    document.getElementById("timerArc").style.strokeDashoffset = offset;
    document.getElementById("timerNum").textContent = nextIn;

    // sim clock
    const t = (data.snapshot.sim_time || "").replace("T", " ").slice(0, 16);
    document.getElementById("simClock").textContent = t ? `sim ${t}` : "";

    // warning badge
    const wc = data.open_warning_count || 0;
    const banner = document.getElementById("warnBanner");
    if (wc > 0) {
      banner.hidden = false;
      document.getElementById("warnCount").textContent = `${wc} warning${wc > 1 ? "s" : ""}`;
    } else {
      banner.hidden = true;
    }

    // global stats
    const gs = computeGlobalStats(data.snapshot);
    document.getElementById("gTasks").textContent  = gs.tasks;
    document.getElementById("gTemp").textContent   = gs.avgTemp + "°C";
    document.getElementById("gCheap").textContent  = gs.cheapest;
    document.getElementById("gGreen").textContent  = gs.greenest;

    document.getElementById("liveDot").style.background = "var(--green)";
  } catch (e) {
    document.getElementById("liveDot").style.background = "var(--red)";
  }
}

function tagClass(status) {
  if (status === "executed")       return "tag-executed";
  if (status === "passed")         return "tag-passed";
  if (status === "blocked_for_admin") return "tag-blocked";
  return "tag-error";
}
function entryClass(status) {
  if (status === "executed")       return "executed";
  if (status === "passed")         return "passed";
  if (status === "blocked_for_admin") return "blocked";
  return "error";
}

async function pollLog() {
  try {
    const res  = await fetch("/api/log", { cache: "no-store" });
    const data = await res.json();
    const list = document.getElementById("logList");
    if (!data.entries.length) {
      list.innerHTML = '<div class="log-empty">Waiting for first decision cycle…</div>';
      return;
    }
    list.innerHTML = data.entries.map(e => {
      if (e.error) return `<div class="log-entry error">
        <div class="log-meta">
          <span class="log-action-tag tag-error">ERROR</span>
        </div>
        <div class="log-reasoning">${e.error}</div></div>`;
      const status  = e.result?.status || "unknown";
      const action  = e.decision?.action || "—";
      const reason  = e.decision?.reasoning || "";
      const timeStr = new Date(e.timestamp * 1000).toLocaleTimeString();
      return `
        <div class="log-entry ${entryClass(status)}">
          <div class="log-meta">
            <span class="log-time">${timeStr}</span>
            <span class="log-action-tag ${tagClass(status)}">${action}</span>
          </div>
          <div class="log-reasoning">${reason}</div>
        </div>`;
    }).join("");
  } catch (e) { /* retry next tick */ }
}

function deltaClass(key, val) {
  if (val === 0 || val === null) return "delta-neutral";
  // lower is better for temp, utilization, carbon, price
  const lowerIsBetter = ["temperature_c","utilization","carbon_g_per_kwh","electricity_price"];
  const good = lowerIsBetter.includes(key) ? val < 0 : val > 0;
  return good ? "delta-good" : "delta-bad";
}

async function pollFeedback() {
  try {
    const res  = await fetch("/api/feedback", { cache: "no-store" });
    const data = await res.json();
    const list = document.getElementById("feedbackList");
    if (!data.entries.length) {
      list.innerHTML = '<div class="log-empty">Outcomes appear ~30s after actions.</div>';
      return;
    }
    list.innerHTML = data.entries.map(e => {
      const deltas = e.delta
        ? Object.entries(e.delta).map(([k, v]) => {
            const sign = v > 0 ? "+" : "";
            return `<span class="delta-chip ${deltaClass(k, v)}">${k} ${sign}${v}</span>`;
          }).join("")
        : "";
      return `
        <div class="feedback-entry">
          <div class="feedback-action">${e.action} → ${e.target || "—"}</div>
          <div class="feedback-deltas">${deltas}</div>
        </div>`;
    }).join("");
  } catch (e) { /* retry */ }
}

// ask the agent
document.getElementById("askBtn").addEventListener("click", async () => {
  const input  = document.getElementById("askInput");
  const answer = document.getElementById("askAnswer");
  const q = input.value.trim();
  if (!q) return;
  answer.textContent = "Thinking…";
  answer.classList.add("visible");
  try {
    const res  = await fetch("/api/ask", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question: q }),
    });
    const data = await res.json();
    answer.textContent = data.answer;
  } catch (e) {
    answer.textContent = "Could not reach the agent.";
  }
});
document.getElementById("askInput").addEventListener("keydown", e => {
  if (e.key === "Enter") document.getElementById("askBtn").click();
});

// kick off polling
pollState();
pollLog();
pollFeedback();
setInterval(pollState,    1000);
setInterval(pollLog,      2500);
setInterval(pollFeedback, 5000);
