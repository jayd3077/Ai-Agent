from __future__ import annotations
import os
import json
import time
import threading

from environment import DatacenterEnvironment
from guardrails import Guardrails
from feedback import FeedbackLoop

# thresholds below which the agent should just pass rather than act
TEMP_THRESHOLD_C = float(os.getenv("TEMP_THRESHOLD_C", 68))
UTIL_IMBALANCE_THRESHOLD = float(os.getenv("UTIL_IMBALANCE_THRESHOLD", 0.35))
MIN_NET_PROFIT = float(os.getenv("MIN_NET_PROFIT", 0.0))

DECISION_SCHEMA_HINT = """
Respond with ONLY a JSON object, no prose, in this exact shape:
{
  "reasoning": "1-3 sentences on why",
  "action": "shift_within_server | shift_within_region | migrate_region | pass",
  "params": {
      // for shift_within_server: from_chipset_id, to_chipset_id, task_id
      // for shift_within_region: from_server_id, to_server_id, task_id
      // for migrate_region: from_region_id, to_region_id, task_id,
      //                      bandwidth_cost_estimate, projected_savings
      // for pass: {}
  }
}
"""


class LLMClient:
    """Thin wrapper so you can swap providers via LLM_PROVIDER without
    touching agent logic. Supports 'anthropic' and 'openai' out of the box."""

    def __init__(self):
        self.provider = os.getenv("LLM_PROVIDER", "anthropic").lower()
        default_models = {
            "anthropic": "claude-sonnet-5",
            "openai": "gpt-4o-mini",
            "gemini": "gemini-3.7-flash",
        }
        self.model = os.getenv("LLM_MODEL", default_models.get(self.provider, "gemini-3.7-flash"))

    def complete(self, system_prompt: str, user_prompt: str) -> str:
        if self.provider == "anthropic":
            import anthropic
            client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
            resp = client.messages.create(
                model=self.model,
                max_tokens=500,
                system=system_prompt,
                messages=[{"role": "user", "content": user_prompt}],
            )
            return "".join(b.text for b in resp.content if hasattr(b, "text"))
        elif self.provider == "openai":
            from openai import OpenAI
            client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
            resp = client.chat.completions.create(
                model=self.model,
                messages=[{"role": "system", "content": system_prompt},
                          {"role": "user", "content": user_prompt}],
                max_tokens=500,
            )
            return resp.choices[0].message.content
        elif self.provider == "gemini":
            from google import genai
            from google.genai import types

            api_key = os.getenv("GEMINI_API_KEY")
            if not api_key:
                raise RuntimeError("GEMINI_API_KEY is not configured. Add it to the .env file and restart the server.")

            # google-genai uses the Client-based API; GenerativeAI/generate_text
            # belonged to the older SDK and causes the Gemini decision failures.
            client = genai.Client(api_key=api_key)
            resp = client.models.generate_content(
                model=self.model,
                contents=user_prompt,
                config=types.GenerateContentConfig(
                    system_instruction=system_prompt,
                    max_output_tokens=500,          
                    temperature=0.4,
                    response_mime_type="application/json",
                    response_schema={
                        "type": "object",
                        "properties": {
                            "reasoning": {"type": "string"},
                            "action": {"type": "string", "enum": ["shift_within_server", "shift_within_region", "migrate_region", "pass"]},
                            "params": {"type": "object"},
                        },
                        "required": ["reasoning", "action", "params"],
                    },
                ),
            )
            return resp.text
        else:
            raise ValueError(f"Unsupported LLM_PROVIDER: {self.provider}")


class DatacenterAgent:
    def __init__(self, env: DatacenterEnvironment, guardrails: Guardrails,
                 feedback: FeedbackLoop, decision_interval: int = 5):
        self.env = env
        self.guardrails = guardrails
        self.feedback = feedback
        self.decision_interval = decision_interval
        self.llm = LLMClient()
        self.decision_log: list[dict] = []
        self._running = False

    # ---- prompt construction ----------------------------------------------
    def _system_prompt(self) -> str:
        donts = "\n".join(f"- {d}" for d in self.guardrails.admin_donts) or "(none set)"
        return f"""You are an autonomous datacenter operations agent.

Your ONLY job: decide whether to shift a task between chipsets, servers, or
regions to reduce overheating, reduce latency for priority tasks, or save
energy cost/carbon -- in that priority order. You act every {self.decision_interval}
seconds on a frozen snapshot of the last {self.decision_interval} seconds of telemetry.

Priority order (highest first):
1. Any chipset above {TEMP_THRESHOLD_C}C -> shift_within_server to a cooler
   chipset on the same server.
2. A high-priority task stuck on a low-tier server while a 'powerful' tier
   server in the same region has headroom -> shift_within_region.
3. A region has a much cheaper/greener electricity price right now, and the
   projected savings minus bandwidth cost is > {MIN_NET_PROFIT} -> migrate_region.
   If net profit <= 0, DO NOT migrate -- choose pass instead.

You do NOT have to act every cycle. If nothing crosses a meaningful
threshold, output action "pass". Passing is a normal, good outcome.

You may NEVER shut down a server/region, or move an entire server's worth
of tasks at once -- those are high-criticality actions reserved for a human
Admin. If you believe one is warranted, say so in "reasoning" but still
output action "pass" (a separate system will flag it for Admin review).

Admin has also set these hard rules you must never violate:
{donts}

Once a task has been moved, it is locked and cannot be moved again until
it completes -- don't try to move already-locked tasks.

{DECISION_SCHEMA_HINT}"""

    def _user_prompt(self, buffer_snapshot: list[dict], recent_feedback: list[dict]) -> str:
        latest = buffer_snapshot[-1] if buffer_snapshot else {}
        return json.dumps({
            "latest_snapshot": latest,
            "recent_action_outcomes": recent_feedback,
        }, indent=2)

    # ---- one decision cycle -----------------------------------------------
    def decide_once(self):
        buffer_snapshot = self.env.swap_buffers()
        if not buffer_snapshot:
            return None
        recent_feedback = self.feedback.recent_summary()

        raw = self.llm.complete(self._system_prompt(),
                                  self._user_prompt(buffer_snapshot, recent_feedback))
        try:
            cleaned = raw.strip()
            if cleaned.startswith("```"):
                cleaned = cleaned.split("\n", 1)[-1]
                cleaned = cleaned.rsplit("```", 1)[0]
            decision = json.loads(cleaned)
            if not isinstance(decision, dict):
                raise ValueError("response is not a JSON object")
        except (json.JSONDecodeError, ValueError):
            decision = {"reasoning": "failed to parse LLM output, defaulting to pass",
                         "action": "pass", "params": {}}

        result = self._execute(decision)
        self.decision_log.append({
            "timestamp": time.time(),
            "decision": decision,
            "result": result,
        })
        return result

    def _execute(self, decision: dict) -> dict:
        action = decision.get("action", "pass")
        params = decision.get("params", {}) or {}

        verdict = self.guardrails.evaluate(action, params)
        if verdict["verdict"] == "pass":
            return {"status": "passed"}
        if verdict["verdict"] == "block":
            return {"status": "blocked_for_admin", "warning_id": verdict["warning"].id}

        # allowed -> execute against the environment
        if action == "shift_within_server":
            outcome = self.env.shift_within_server(**params)
        elif action == "shift_within_region":
            outcome = self.env.shift_within_region(**params)
        elif action == "migrate_region":
            outcome = self.env.migrate_region(**params)
        else:
            return {"status": "unknown_action"}

        if outcome.get("ok"):
            self.feedback.record(action, params)
        return {"status": "executed", "outcome": outcome}

    # ---- background loop ---------------------------------------------------
    def run_forever(self):
        self._running = True

        def loop():
            while self._running:
                try:
                    self.decide_once()
                except Exception as e:
                    self.decision_log.append({"timestamp": time.time(), "error": str(e)})
                time.sleep(self.decision_interval)

        threading.Thread(target=loop, daemon=True).start()

    def stop(self):
        self._running = False
